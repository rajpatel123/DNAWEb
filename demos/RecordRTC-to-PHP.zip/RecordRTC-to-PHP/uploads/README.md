## Source Code:

https://github.com/muaz-khan/RecordRTC/tree/master/RecordRTC-to-PHP

This directory contains wav/webm files.