<audio controls loop autoplay>
    <source src="uploads/37181738107447295.wav" type="audio/wav">
    <!--<source src="upload/20471384979646736.wav" type="audio/ogg">-->
</audio>


                       <video controls>
                       <source src="upload/4664501528.webm" type="video/gif">
                       <source src="upload/4664501528.webm" type="video/webm">
                       </video>
					   
					   
					   <video src="upload/4664501528.ogg" controls>
  Your browser does not support the <code>video</code> element.
</video>